//CLIENT API
const express = require('express')
var sqlite3 = require('sqlite3').verbose();
var cors = require('cors');
const app = express()
const port = 3000
app.use(cors());

var log = function(process, errorcode, data){
	var datestamp = new Date().toISOString().slice(0, 19).replace('T', ' ');
	console.log(datestamp + ':' + process + " | " + errorcode + " | " + data + '\n\r');
}

app.get("/ps/invoke/:file", (req, res, next) => {
	var file = req.params.file;
	var ext = file.split('.').pop();
	if (ext == 'ps1'){
		log('API','A002','Executing :' + file);
		var shell = require('node-powershell');
		
		
		var ps = new shell({
			executionPolicy: 'bypass',
			noProfile: true
		});
		
		ps.addCommand(".\\ps\\" + file);
		ps.invoke()
		.then(function(output){
			console.log(output);
			res.send(output);
			
		})
		.then(function(newoutput){
			log('API','A007','PS Stopped :' + file + " - " + newoutput);
			ps.dispose()
			res.send(newoutput)
			.then(code => {
				log('API','A008','PS Stopped :' + file + " - " + code);
				res.send(code);
			})
			.catch(error => {
				log('API','ERR004','PS Failed to Stop :' + file + " - " + error);
				res.send("failed");
			});
		})
		.catch(function(err){
			console.log(err)
			res.send("failed");
			ps.stop();
			ps.dispose();
		});
	}
	if (ext == 'js'){
		const { spawn } = require('child_process');
		if (file == 'TaskManager.js'){
			child = spawn("node",[file]);
		}else{
			child = spawn("node",['.\\js\\' + file]);
		}
		log('API','A002','Executing :' + file);
		child.stdout.on("data",function(data){
			log('API','A0017','JS Executed :' + file + " - " + data);
			
		});
		child.stderr.on("data",function(data){
			log('API','ERR004','JS Failed to Stop :' + file + " - " + data);
		});
		child.on("exit",function(){
			log('API','A0016','JS Finished :' + file);
		});
		child.stdin.end();
	}
 });

 app.get("/logs/", (req, res, next) => {
	let logdb = new sqlite3.Database('./db/log.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
			if (err){
				console.error("Database Connection error");
				res.send("error");
			}else{
				//console.log('Connected to log database.');
			}
		});
		
	logdb.all("SELECT * FROM log where syncstatus = 0", function(err, rows) {
		res.send(rows);
		//logdb.close();
	});
	
 });
 
app.get('/sysinfo', function(req, res) {
    res.sendFile(__dirname + '/ps/SystemReport.html');
});
 
 app.get("/logs/update/:id", (req, res, next) => {
	var id = req.params.id;
	let logdb = new sqlite3.Database('./db/log.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
			if (err){
				console.error("Database Connection error");
				res.send("error");
			}else{
				//console.log('Connected to log database.');
			}
		});
		
		let sql = 'update log set syncstatus = 1 where id = 35' + id;
		logdb.run(sql,[], function(err) {
			if (err) {
				res.send("error");
			}else{
				//logdb.close();
				res.send("ok");
			}
		});
	
 });
 // CREATE TABLE log (id INTEGER PRIMARY KEY AUTOINCREMENT, process TEXT,errorcode TEXT,data TEXT,datestamp DATETIME,syncstatus INT);
 
 app.get("/", (req, res, next) => {
	res.send('Hi');
 	res.end();
 });
app.listen(port, () => log('API','A001','Powestack API Listenting on 3000'))