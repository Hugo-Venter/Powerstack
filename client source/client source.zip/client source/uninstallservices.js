var Service = require('node-windows').Service;

// Create a new service object
var svc1 = new Service({
  name:'Powerstack Web API',
  description: 'Powerstack Web API',
  script: 'C:\\Program Files (x86)\\PowerStack Client\\API.js',
  nodeOptions: [
    '--harmony',
    '--max_old_space_size=4096'
  ]
});

// Listen for the "install" event, which indicates the
// process is available as a service.
svc1.on('install',function(){
  svc1.start();
});

svc1.uninstall();

var svc2 = new Service({
  name:'Powerstack Task Manager',
  description: 'Powerstack Task Manager',
  script: 'C:\\Program Files (x86)\\PowerStack Client\\TaskManager.js',
  nodeOptions: [
    '--harmony',
    '--max_old_space_size=4096'
  ]
});

// Listen for the "install" event, which indicates the
// process is available as a service.
svc2.on('install',function(){
  svc2.start();
});
svc2.uninstall();
