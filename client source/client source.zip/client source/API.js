const express = require('express')
var sqlite3 = require('sqlite3').verbose();
var cors = require('cors');
const app = express()
const port = 3000
app.use(cors());

app.get("/ps/invoke/:file", (req, res, next) => {
	var file = req.params.file;
	var shell = require('node-powershell');

	var ps = new shell({
		executionPolicy: 'bypass',
		noProfile: true
	});
	
	ps.addCommand(".\\ps\\" + file);
	ps.invoke()
	.then(function(output){
		//console.log(output);
		res.send(output);
	})
	.then(function(newoutput){
		ps.dispose()
		.then(code => {})
		.catch(error => {});
		
	})
	.catch(function(err){
		console.log(err)
		res.send("failed");
		ps.stop();
		ps.dispose();

	});
		
	
 });

 app.get("/logs/", (req, res, next) => {
	let logdb = new sqlite3.Database('./db/log.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
			if (err){
				console.error("Database Connection error");
				res.send("error");
			}else{
				console.log('Connected to log database.');
			}
		});
		
	logdb.all("SELECT * FROM log where syncstatus = 0", function(err, rows) {
		res.send(rows);
		logdb.close();
	});
	
 });
 
app.get('/sysinfo', function(req, res) {
    res.sendFile('ps/SystemReport.html');
});
 
 app.get("/logs/update/:id", (req, res, next) => {
	var id = req.params.id;
	let logdb = new sqlite3.Database('./db/log.db', sqlite3.OPEN_READWRITE | sqlite3.OPEN_CREATE, (err) => {
			if (err){
				console.error("Database Connection error");
				res.send("error");
			}else{
				console.log('Connected to log database.');
			}
		});
		
		let sql = 'update log set syncstatus = 1 where id = 35' + id;
		logdb.run(sql,[], function(err) {
			if (err) {
				res.send("error");
			}else{
				logdb.close();
				res.send("ok");
			}
		});
	
 });
 // CREATE TABLE log (id INTEGER PRIMARY KEY AUTOINCREMENT, process TEXT,errorcode TEXT,data TEXT,datestamp DATETIME,syncstatus INT);
 
 app.get("/", (req, res, next) => {
	res.send('Hi');
 	res.end();
 });
app.listen(port, () => console.log('Powerstack API listening on port 3000!'))